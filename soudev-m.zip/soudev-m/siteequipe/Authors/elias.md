## Elias Fernandes

- FullStack Developer
> Fortaleza, Ceará, Brasil


```
Resiliência sempre....
```

```html
<head class="teste">Liberdade pra dentro da cabeça</head>

```
---

[Site/Curriculo](https://eliasfernandes02.github.io)

[instagram](https://github.com/EliasFernandes02)
