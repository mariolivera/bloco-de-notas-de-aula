## mario
- fullstack developer
---
- [site/curriculo](https://mariolivera.github.oi)
edit