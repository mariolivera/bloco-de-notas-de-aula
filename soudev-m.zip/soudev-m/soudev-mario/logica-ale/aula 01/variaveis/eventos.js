/*bdocument.write('ola mundo');
document.write ('<br>');
document.write(10+10-10.6/2);/*float*/
/*bdocument.write(!false);/*boolean*/

let numero = 10;/* Usuando o  "let" estou criando uma variavel no banco de dados, nesse caso o 10 foi substituido pelo 20, pelo efeito cascata */
numero = '20';/* quando se coloca uma string ele se torna algo diferente de numero, logo ele não irar operar a soma*/
numero = 20 + numero;

document.write(numero);

let nome_Completo = 'Mario oliveira'; 
// nome_Completo = nome_Completo + 'Batista';//
nome_Completo += 'batista';

document.write (numero);
document.write ('<br>' + nome_Completo);

let senha = '123qwe123'; 
const SENHA = '123qwe123';// sempre que usar uma constante usa as letras maiusculas, as letras em minuscula são variaveis// 
