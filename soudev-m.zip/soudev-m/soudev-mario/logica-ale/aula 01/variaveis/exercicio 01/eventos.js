function somar() {
    resultado.innerHTML =Number(numero1.value) + Number(numero2.value);//para ativar a função da soma precisamos colocar a função "Number" e colocar os valores em paretenses, pq isso acontece? pq no javascript ele  usa o "+" para contatenar tambem// 
}
function subtração() {
    resultado.innerHTML = numero1.value - numero2.value;
}
function multiplicar() {
    resultado.innerHTML = numero1.value * numero2.value;
}
function dividir() {
    resultado.innerHTML = numero1.value / numero2.value;
}