
let dia = 1; //inicio
while (dia <= 31) {//fim condição/ usamos o while pq ele quer dizer enquanto.

    selectDia.innerHTML += `<Option>${dia}</Option>`;

    dia++; // passo/incremento
    //dia = dia +1 essa opção deixa codigo mais lento pois faz uma trabalho extra
}
let meses = [
    'janeiro',
    'fervereiro',
    'março',
    'abril',
    'maio',
    'junho',
    'julho',
    'agosto',
    'outubro',
    'setembro',
    'novembro',
    'dezembro',    
];

meses.forEach(function (cadaMes){
    selectMes.innerHTML += `<Option>${cadaMes}</Option>`;
});

//let mes = 1;
//while (mes <= 12) {

//    selectMes.innerHTML += `<Option>${mes}</Option>`;

   // mes++;
//} essa é mais uma forma de de fazer o calendario mes com números. para ele entrar só apagar do 'let meses' ate o ';' caso contrario provoca um conflito entre os codigos.

let ano = 2022;
while (ano >= 1900) {

    selectAno.innerHTML += `<Option>${ano}</Option>`;

    ano--;// qunado você quiser fazer o ano em forma de decrecimo ou decremento usa-se o ano-- pq assim ele vai subtraindo os anos. 
}