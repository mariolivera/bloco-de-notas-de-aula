let alunos = [
    ['aluno1', 'aluno1@email.com','85 8888-8888',],
    ['aluno2', 'aluno2@email.com','85 8888-8888'],
    ['aluno3', 'aluno3@email.com','85 8888-8888'],
    ['aluno4', 'aluno24@email.com','85 8888-8888'],
];


function novo(){
    pagina_novo.style.display = 'block';
    pagina_listar.style.display ='none';
}


function listar(){
    pagina_listar.style.display = 'block';
    pagina_novo.style.display ='none';

    alunos.forEach(function(cadaAluno) {
        tabela_alunos.innerHTML += `
            <tr>
                <td>${cadaAluno[0]}</td>
                <td>${cadaAluno[1]}</td>
                <td>${cadaAluno[2]}</td>
                <td>---</td>
            </tr>
        `;       
    });
}