function soma(valor1,valor2){
    let total= valor1 + valor2;
    console.log(total)
    return valor1 + valor2;
}

console.log(soma(1,soma(1, 1)))

let x = soma(1, soma(3, (3+3)));
 console.log(x)