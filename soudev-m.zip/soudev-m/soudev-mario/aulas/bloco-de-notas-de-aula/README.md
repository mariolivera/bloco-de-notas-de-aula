# bloco-de-notas-de-aula
anotações da aula do dia 08/09/22
