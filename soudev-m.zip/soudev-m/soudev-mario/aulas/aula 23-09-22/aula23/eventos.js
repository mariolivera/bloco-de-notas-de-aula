let arreyNumeros = [3]

/*for (let index = 0; index < arreyNumeros.length; index);{
    let element = arreyNumeros[index];

        console.log(element)
//}*/


function carro(torre){  /* esse caso o foreach vai chamar a funtion com todas os parametros  SEMPRE que eu chamar o for each ele vai chamas todos os elemntos do array*/
    console.log(torre)
}

arreyNumeros.forEach(carro) /* for (let i =0; i < arraynumero;i++) console.log(i) */