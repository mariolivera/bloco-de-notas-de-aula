/*let arrayNumeros = ['maria','Joao','alves','Carvalho','leandro']*/
/*let arrayNumeros = [1234,3214,55667,43216,98365,]*/



/*for (let index = 0; index < arreyNumeros.length; index);{
    let element = arreyNumeros[index];

        console.log(element)
//}*/


/*function carro(torre){  /* esse caso o foreach vai chamar a funtion com todas os parametros  SEMPRE que eu chamar o for each ele vai chamas todos os elemntos do array ele faz uma interação sobre os elementos do array*/
 //*   console.log(torre)
/*}*/

/*arreyNumeros.forEach((carro) =>{
    console.log(carro,' '+1 )
    document.write(carro, ' ','maria')
}) /* for (let i =0; i < arraynumero;i++) console.log(i)  o foreach não retorna nada ele é uma funtion sem retorno*/

/*arreyNumeros.some(function(element){
    console.log(element)
    return element === 'jose'
})*/      /*  pode ser usado para por exemplo buscar um elemento especifico, como um cpf especifico. o some sempre retorna um boolean*/

/*let resultado = arrayNumeros.find(function(element){
    console.log(element)    
    return element !== 3
})*/ 
/* o find ele encontra e retorna um elemento do array que ele achar*/

/*let resultado = arrayNumeros.filter(function(element){
    console.log(element) 
    return element[0].toUpperCase() !== element[0];
})/* ele filtra os elementos especificos*/

/*let array =[]

arrayNumeros.forEach(function(element){
    if(element.lastIndexOf("o") === element.length -1)
    array.push(element)
});
console.log(array)/*nesse caso o push, vai adicionar todos os nomes que termina com "o" e joga no console.log, */



let arrayPessoa =[
    {nome: "alves", idade:2, cpf:"022.221.223-21", cep: "62150-123"},
    {nome: "alves", idade:2, cpf:"022.221.223-21", cep: "60167-156"},
    {nome: "alves", idade:2, cpf:"022.221.223-21", cep: "61178-133"},
    {nome: "alves", idade:2, cpf:"022.221.223-21", cep: "65154-144" }]

console.log(arrayPessoa.filter(function(Element){
    return Element.cep.indexOf("60") === 0
}))