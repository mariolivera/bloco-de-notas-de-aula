/*let a = 1
let b = 'string'
let c = true
let d = []
let e = {}

function idade(){
    return 33
}
let Mario {
    nome: mario;
    idade: 33;
    idade1: 33;

}

let = abcd; /* aqui o abcd é uma funçao assim como imprimir */

/*function imprimir(){
    console.log(1)
}

imprimir()/* isso é uma execução*/


/** -------------------------------------------------*/
/*na opção const, vc naõ pode mudar o valor da const, mas pode mudar as variaveis 
/*document.getElementById('texto1')

console.log(a.textContent)

a.textContent = 1234

document.getElementById('texto1').textContent = 'abcd'
document.getElementById('input1').textContent = 'abcd'*/

/*let input1 =document.getElementById('input1')
input1.focus();
input1.value =4;*/

